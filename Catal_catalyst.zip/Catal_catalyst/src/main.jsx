import React from "react";
import ReactDOM from "react-dom/client";
import App from "./app/App";

// Import global styles if you have any, e.g.:
// import "../styles/global.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
